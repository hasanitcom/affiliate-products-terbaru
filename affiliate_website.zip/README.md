# Website Affiliate Produk

Website sederhana untuk menampilkan produk affiliate yang bisa kamu tambah sendiri lewat form.

## Cara Pakai

1. Buka file `index.html` di browser (klik 2x atau drag ke browser).  
2. Isi form "Tambah Produk Baru" dengan:  
   - URL gambar produk (contoh: https://example.com/image.jpg)  
   - Nama produk  
   - Deskripsi singkat produk  
   - Link affiliate (Shopee, Tokopedia, dll)  
3. Klik tombol "Tambah Produk". Produk akan langsung muncul di bawah form.  
4. Data produk akan tersimpan di browser kamu (localStorage), jadi tetap ada walau refresh halaman.  
5. Untuk menghapus produk, klik tombol "Hapus" pada kartu produk.

## Hosting Online (Optional)

Kamu bisa upload file ini ke hosting gratis seperti [GitHub Pages](https://pages.github.com/) supaya website bisa diakses dari mana saja.

- Buat repository GitHub baru  
- Upload file `index.html`  
- Aktifkan GitHub Pages pada branch utama  
- Buka link yang diberikan GitHub Pages

Selamat mencoba! Kalau ingin versi dengan database online (Firebase), hubungi aku ya!

